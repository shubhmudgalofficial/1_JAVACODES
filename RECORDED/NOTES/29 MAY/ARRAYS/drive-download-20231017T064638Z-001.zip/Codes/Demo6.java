// ArrayIndexOutOfBoundsException:



public class Demo6{
	public static void main(String[] args){
	
		int a[]={5,6,7,8};
		System.out.println(a[4]);
	}
}



Output: ArrayIndexOutOfBoundsException