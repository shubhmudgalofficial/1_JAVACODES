
public class Demo7{
	public static void main(String[] args){
	
		int a[]={5,8,4,3};
			System.out.println(a[a.length-1]);
			System.out.println("Bye");
	}
}














