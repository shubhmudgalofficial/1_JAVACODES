public class Demo2{
	public static void main(String[] args){
		
	String name= "Navin";
	System.out.println(name.length());
	}
}