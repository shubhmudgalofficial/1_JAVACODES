class Test
{
    int a = 2;
    String name = "John";
    public static void main(String[] args) {
        // declare the variable
        // create the object
        int num = 9;
        Test obj = new Test();
        Test obj1 = new Test();

        obj.name = "Navin";

        System.out.println(obj.a);
        System.out.println(obj.name);
        System.out.println(obj1.a);
        System.out.println(obj1.name);


    }
}